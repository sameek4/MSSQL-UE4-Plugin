﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class AdaptiveSharpenEffect : MonoBehaviour {

	public float CurveHeight = 1;
	private Material material;

	// Creates a private material used to the effect
	void Awake ()
	{
		material = new Material( Shader.Find("Hidden/AdaptiveSharpen") );
	}

	// Postprocess the image
	void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		

		material.SetFloat("_CurveHeight", CurveHeight);
		Graphics.Blit (source, destination, material);
	}
}