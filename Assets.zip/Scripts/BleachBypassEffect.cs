﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class BleachBypassEffect : MonoBehaviour {

	public float Opacity = 1;
	public Color32 Coefficient =  new Color32 (64 , 166 , 26 , 255);
	private Material material;

	// Creates a private material used to the effect
	void Awake ()
	{
		material = new Material( Shader.Find("Hidden/BleachBypass") );
	}

	// Postprocess the image
	void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		
		material.SetFloat("_Opacity", Opacity);
		material.SetColor ("_Coefficient", Coefficient);
		Graphics.Blit (source, destination, material);
	}
}