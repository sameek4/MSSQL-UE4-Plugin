﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class PostComplementEffect : MonoBehaviour {

	public bool ForceHue = false;
	public Color32 GuideHue =  new Color32 (0 , 0 , 255 , 255);
	public float DesatCorr = 0.2f;
	public float Amount = 0.2f;
	public float Concentrate = 4;
	private Material material;

	// Creates a private material used to the effect
	void Awake ()
	{
		material = new Material( Shader.Find("Hidden/PostComplement") );
	}

	// Postprocess the image
	void OnRenderImage (RenderTexture source, RenderTexture destination)
	{

		material.SetFloat("_ForceHue", ForceHue?1:0);
		material.SetColor ("_GuideHue", GuideHue);
		material.SetFloat("_DesatCorr", DesatCorr);
		material.SetFloat ("_Amount", Amount);
		material.SetFloat ("_Concentrate", Concentrate);
		Graphics.Blit (source, destination, material);
	}
}
